package com.apress.springrecipes.cloud;

/**
 * Created by marten on 03-10-14.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World from CloudFoundry.");
    }

}
