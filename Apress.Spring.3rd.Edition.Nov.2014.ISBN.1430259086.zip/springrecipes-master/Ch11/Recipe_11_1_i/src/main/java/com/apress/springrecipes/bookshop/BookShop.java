package com.apress.springrecipes.bookshop;

public interface BookShop {

    public void purchase(String isbn, String username);

}
